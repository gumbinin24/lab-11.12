import requests


r_get = requests.get("https://httpbin.org/get")
r_post = requests.post("https://httpbin.org/post", data={'key': 'value'})
r_options = requests.options("https://httpbin.org/get")


with open("results.txt", "w", encoding="utf-8") as file:
    file.write("GET" + "\n")
    file.write(f'Ответ сервера: {r_get.status_code}, {r_get.reason}'+ "\n")
    file.write(f'Заголовки ответа: {r_get.headers} + "\n"')
    file.write(f'Содержимое ответа:{r_get.text} + "\n"' + "\n")

    file.write("POST" + "\n")
    file.write(f'Ответ сервера: {r_post.status_code}, {r_post.reason}' + "\n")
    file.write(f'Заголовки: {r_post.headers}' + "\n")
    file.write(f'Содержимое ответа: {r_post.json()}' + "\n")

    file.write("OPTION" + "\n")
    file.write(f'Ответ сервера: {r_options.status_code}, {r_options.reason}' + "\n")
    file.write(f'Заголовки: {r_options.headers}' + "\n")
    file.write(f'Содержимое ответа: {r_options.text} + "\n"')